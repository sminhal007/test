const express = require('express')
var mysql = require('mysql');
var bodyParser = require('body-parser');
const app = express()
const port = 5000

// app.get('/', (req, res) => {
//   res.send('Hello how are you minhal!')
// })

app.use(express.static("public"))
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



app.get('/minhal', (req, res) => {
    res.send('Hello this is the new router!')
  })

app.get('/', function(req, res){
    // res.sendFile(__dirname + '/home.html');
    res.sendFile('home.html', {root: 'public'});
});

app.post('/formsubmit', (req, res) => {
    console.log(req.body)
    // var sql = `INSERT INTO my_data1 (fname,lname,email,username,password,confirmpassword)  VALUES (${req.body.fname}, ${req.body.lname},${req.body.email},${req.body.username},${req.body.password},${req.body.confirmpassword})`;
    var sql=`INSERT INTO my_data SET fname='${req.body.fname}',lname='${req.body.lname}',email='${req.body.email}',username='${req.body.username}',password='${req.body.password}',confirmpassword='${req.body.ConfirmPassword}' `;

  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
    res.send(`Hi ${req.body.fname} your record has been inserted in SQL`)
  })


var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "mydb"
  });
  



 con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    // var sql = "CREATE TABLE my_data1 ( fname VARCHAR(255), lname VARCHAR(255),email VARCHAR(255), username VARCHAR(255),password VARCHAR(255),confirmpassword VARCHAR(255))";
    // con.query(sql, function (err, result) {
    //   if (err) throw err;
    //   console.log("Table created");
    // });
  });

app.listen(port, () => {
  console.log(`My app listening on port ${port}`)
})